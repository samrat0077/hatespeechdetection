import React from 'react';
import { Shield, AlertTriangle, Heart } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    icon: Shield,
    title: 'Protect Your Community',
    description: 'Identify and prevent harmful content before it affects your users.'
  },
  {
    icon: AlertTriangle,
    title: 'Early Detection',
    description: 'Catch potentially harmful content early to maintain a safe environment.'
  },
  {
    icon: Heart,
    title: 'Foster Inclusivity',
    description: 'Create a welcoming space where everyone feels safe and respected.'
  }
];

export function InfoSection() {
  return (
    <div className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Why Use Our Hate Speech Detector?
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Create safer online spaces with our advanced content analysis tools.
          </p>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                className="relative p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="absolute top-0 -translate-y-1/2 bg-blue-600 rounded-full p-3">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="mt-8 text-xl font-medium text-gray-900">{feature.title}</h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}