import React, { useState, useCallback } from 'react';
import TextareaAutosize from 'react-textarea-autosize';
import { AlertTriangle, Shield, ShieldCheck, BarChart2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { analyzeText } from '../utils/textAnalysis';
import { highlightText } from '../utils/textHighlighting';
import type { AnalysisResult } from '../utils/types';

export function TextAnalyzer() {
  const [text, setText] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [highlightedText, setHighlightedText] = useState('');

  const handleAnalyze = useCallback(() => {
    if (!text.trim()) return;
    const analysis = analyzeText(text);
    setResult(analysis);
    setHighlightedText(highlightText(text));
  }, [text]);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <TextareaAutosize
        className="w-full p-4 border rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all resize-none"
        minRows={3}
        placeholder="Enter text to analyze..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
        onClick={handleAnalyze}
        disabled={!text.trim()}
      >
        Analyze Text
      </motion.button>

      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {/* Highlighted Text Display */}
            <div className="bg-white rounded-lg p-6 shadow-lg">
              <h3 className="text-lg font-semibold mb-3">Analyzed Text:</h3>
              <div
                className="prose max-w-none"
                dangerouslySetInnerHTML={{ __html: highlightedText }}
              />
            </div>

            {/* Analysis Results */}
            <div
              className="rounded-lg p-6 shadow-lg"
              style={{
                backgroundColor: 
                  result.category === 'safe' ? 'rgb(220 252 231)' :
                  result.category === 'warning' ? 'rgb(254 249 195)' :
                  'rgb(254 226 226)'
              }}
            >
              <div className="flex items-center space-x-3">
                {result.category === 'safe' && <ShieldCheck className="w-6 h-6 text-green-600" />}
                {result.category === 'warning' && <Shield className="w-6 h-6 text-yellow-600" />}
                {result.category === 'toxic' && <AlertTriangle className="w-6 h-6 text-red-600" />}
                <h3 className="text-lg font-semibold capitalize">
                  {result.category === 'safe' ? 'Safe Content' :
                   result.category === 'warning' ? 'Potentially Harmful' :
                   'Toxic Content Detected'}
                </h3>
              </div>

              {result.details.length > 0 && (
                <ul className="mt-3 space-y-1">
                  {result.details.map((detail, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="text-sm flex items-center space-x-2"
                    >
                      <BarChart2 className="w-4 h-4" />
                      <span>{detail}</span>
                    </motion.li>
                  ))}
                </ul>
              )}

              <div className="mt-4 w-full bg-white rounded-full h-2">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${result.score}%` }}
                  className="h-full rounded-full"
                  style={{
                    backgroundColor:
                      result.category === 'safe' ? 'rgb(34 197 94)' :
                      result.category === 'warning' ? 'rgb(234 179 8)' :
                      'rgb(239 68 68)'
                  }}
                />
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                {Object.entries(result.detections).map(([category, count]) => (
                  count > 0 && (
                    <div key={category} className="flex items-center justify-between">
                      <span className="capitalize">{category}:</span>
                      <span className="font-semibold">{count}</span>
                    </div>
                  )
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}