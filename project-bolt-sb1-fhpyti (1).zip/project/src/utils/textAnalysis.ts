import { regionalDiscrimination, religiousDiscrimination, ethnicDiscrimination, culturalAppropriation } from './wordLists/categories/discrimination';
import { politicalExtremism, violenceAdvocacy } from './wordLists/categories/extremism';
import { personalAttacks, cyberbullying, sexualHarassment } from './wordLists/categories/harassment';
import { adultContent, explicitLanguage, illegalContent } from './wordLists/categories/nsfw';
import type { AnalysisResult } from './types';

const allWordLists = {
  discrimination: [...regionalDiscrimination, ...religiousDiscrimination, ...ethnicDiscrimination, ...culturalAppropriation],
  extremism: [...politicalExtremism, ...violenceAdvocacy],
  harassment: [...personalAttacks, ...cyberbullying, ...sexualHarassment],
  adult: [...adultContent, ...explicitLanguage],
  illegal: [...illegalContent]
};

function normalizeText(text: string): string {
  return text.toLowerCase()
    .replace(/[^\w\s]/g, '') // Remove punctuation
    .replace(/\d/g, '')      // Remove numbers
    .replace(/\s+/g, ' ')    // Normalize whitespace
    .trim();
}

function findMatches(text: string, wordList: string[]): string[] {
  const normalizedText = normalizeText(text);
  const words = normalizedText.split(' ');
  
  // Check for exact matches
  const exactMatches = wordList.filter(word => 
    words.includes(word) || normalizedText.includes(word)
  );
  
  // Check for partial matches (for compound words and variations)
  const partialMatches = wordList.filter(word => 
    !exactMatches.includes(word) && // Avoid duplicates
    (words.some(w => w.includes(word)) || normalizedText.includes(word))
  );
  
  return [...new Set([...exactMatches, ...partialMatches])];
}

function calculateScore(detections: Record<string, number>): number {
  const weights = {
    discrimination: 0.9,  // Very severe
    extremism: 1.0,      // Most severe
    harassment: 0.8,     // Severe
    adult: 0.6,         // Moderate
    illegal: 0.9        // Very severe
  };

  const baseScore = Object.entries(detections).reduce((sum, [category, count]) => {
    const weight = weights[category as keyof typeof weights];
    return sum + (count * weight);
  }, 0);

  // Apply logarithmic scaling to prevent extreme scores
  const scaledScore = Math.log1p(baseScore) * 25;
  
  // Ensure score is between 0 and 100
  return Math.min(100, Math.max(0, scaledScore));
}

function getCategoryDetails(matches: string[], category: string): string[] {
  const details: string[] = [];
  
  if (matches.length > 0) {
    switch (category) {
      case 'discrimination':
        details.push('Contains discriminatory content');
        details.push('Potentially harmful to specific groups');
        if (matches.length >= 3) {
          details.push('High frequency of discriminatory terms detected');
        }
        break;
      case 'extremism':
        details.push('Contains extremist content');
        details.push('Potentially dangerous or threatening content');
        if (matches.some(m => m.includes('kill') || m.includes('death'))) {
          details.push('Violent threats detected');
        }
        break;
      case 'harassment':
        details.push('Contains harassing content');
        details.push('Personal attacks or bullying detected');
        if (matches.length >= 3) {
          details.push('Multiple instances of harassment detected');
        }
        break;
      case 'adult':
        details.push('Contains adult/NSFW content');
        details.push('Inappropriate for general audience');
        break;
      case 'illegal':
        details.push('Contains potentially illegal content');
        details.push('References to prohibited activities detected');
        break;
    }
  }
  
  return details;
}

export function analyzeText(text: string): AnalysisResult {
  const detections = {
    discrimination: findMatches(text, allWordLists.discrimination).length,
    extremism: findMatches(text, allWordLists.extremism).length,
    harassment: findMatches(text, allWordLists.harassment).length,
    adult: findMatches(text, allWordLists.adult).length,
    illegal: findMatches(text, allWordLists.illegal).length
  };

  const score = calculateScore(detections);
  
  // Gather detailed analysis
  const details: string[] = [
    ...getCategoryDetails(findMatches(text, allWordLists.discrimination), 'discrimination'),
    ...getCategoryDetails(findMatches(text, allWordLists.extremism), 'extremism'),
    ...getCategoryDetails(findMatches(text, allWordLists.harassment), 'harassment'),
    ...getCategoryDetails(findMatches(text, allWordLists.adult), 'adult'),
    ...getCategoryDetails(findMatches(text, allWordLists.illegal), 'illegal')
  ];

  // Determine overall category
  let category: AnalysisResult['category'];
  if (score >= 70 || detections.extremism > 0 || detections.illegal > 0) {
    category = 'toxic';
  } else if (score >= 30 || detections.discrimination > 0 || detections.harassment > 0) {
    category = 'warning';
  } else {
    category = 'safe';
  }

  return {
    score,
    category,
    detections,
    details
  };
}