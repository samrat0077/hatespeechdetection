export type ContentCategory = 'safe' | 'warning' | 'toxic';

export interface AnalysisResult {
  score: number;
  category: ContentCategory;
  detections: {
    discrimination: number;
    extremism: number;
    harassment: number;
    adult: number;
    illegal: number;
  };
  details: string[];
}