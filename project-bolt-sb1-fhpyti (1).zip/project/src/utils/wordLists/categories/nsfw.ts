// Adult Content
export const adultContent = [
  // General Indicators
  'nsfw', 'xxx', 'porn', 'pornographic', 'adult',
  'mature', '18+', 'rated x', 'explicit', 'erotic',
  
  // Adult Industry
  'escort', 'stripper', 'webcam', 'onlyfans',
  'premium snap', 'sugar', 'companion', 'model',
  
  // Sexual Content
  'sex', 'sexual', 'sexy', 'seductive', 'kinky',
  'fetish', 'bdsm', 'dominatrix', 'submissive',
  
  // Nudity
  'nude', 'nudity', 'naked', 'topless', 'bottomless',
  'exposed', 'revealing', 'flashing', 'streaking',
  
  // Inappropriate
  'lewd', 'perverted', 'indecent', 'obscene',
  'vulgar', 'graphic', 'explicit', 'inappropriate'
];

// Explicit Language
export const explicitLanguage = [
  // Common Profanity
  'fuck', 'shit', 'ass', 'bitch', 'damn', 'hell',
  'crap', 'piss', 'dick', 'cock', 'pussy', 'cunt',
  
  // Mild Profanity
  'dang', 'darn', 'heck', 'frick', 'shoot', 'crud',
  'jeez', 'gosh', 'drat', 'blast',
  
  // Sexual Terms
  'horny', 'aroused', 'wet', 'hard', 'cum', 'ejaculate',
  'orgasm', 'climax', 'pleasure', 'satisfaction',
  
  // Body Parts
  'penis', 'vagina', 'breast', 'boob', 'ass',
  'butt', 'dick', 'cock', 'pussy', 'clit'
];

// Illegal Content
export const illegalContent = [
  // Exploitation
  'jailbait', 'underage', 'minor', 'child', 'teen',
  'young', 'barely', 'illegal', 'forbidden',
  
  // Drugs
  'cocaine', 'heroin', 'meth', 'crack', 'weed',
  'marijuana', 'drug', 'dealer', 'substance',
  
  // Weapons
  'gun', 'weapon', 'knife', 'explosive', 'bomb',
  'ammunition', 'firearm', 'arsenal', 'illegal',
  
  // Criminal Activity
  'stolen', 'hack', 'crack', 'pirate', 'illegal',
  'criminal', 'fraud', 'scam', 'scheme'
];