// Regional/Cultural Discrimination
export const regionalDiscrimination = [
  // General
  'immigrant', 'foreigner', 'alien', 'outsider', 'go back to', 'go home',
  'illegal alien', 'third world', 'developing country', 'primitive',
  
  // Asia-Pacific
  'fob', 'fresh off', 'boat people', 'mainland', 'islander',
  
  // Europe
  'eastern european', 'gypsy', 'romani', 'slavic', 'balkan',
  
  // Americas
  'wetback', 'beaner', 'spic', 'gringo', 'yankee', 'border jumper',
  
  // Africa
  'jungle bunny', 'kaffir', 'native', 'tribal', 'bushman',
  
  // Middle East
  'sand', 'desert', 'bedouin', 'nomad', 'tribal'
];

// Religious Discrimination
export const religiousDiscrimination = [
  // General
  'islamophobic', 'islamophobia', 'antisemitic', 'antisemitism',
  'kafir', 'infidel', 'heretic', 'heathen', 'pagan',
  'crusader', 'jihad', 'zealot', 'radical',
  
  // Islam
  'muzzie', 'terrorist', 'fundamentalist', 'extremist', 'radical islam',
  
  // Judaism
  'jew', 'zionist', 'hebrew', 'chosen people', 'hook nose',
  
  // Christianity
  'bible thumper', 'holy roller', 'jesus freak', 'fundie', 'papist',
  
  // Hinduism
  'idol worshipper', 'cow worshipper', 'polytheist', 'pagan',
  
  // Buddhism
  'buddha head', 'zen master', 'monk head',
  
  // Sikhism
  'raghead', 'turban head', 'taliban'
];

// Ethnic Discrimination
export const ethnicDiscrimination = [
  // General
  'racist', 'supremacist', 'discrimination', 'supremacy',
  'ethnostate', 'segregation', 'xenophobe', 'xenophobia',
  'pure blood', 'master race', 'ethnic cleansing',
  
  // Asian
  'oriental', 'yellow', 'slant', 'chinaman', 'gook',
  
  // African/Black
  'negro', 'colored', 'coon', 'monkey', 'ape',
  
  // Hispanic/Latino
  'spic', 'wetback', 'beaner', 'illegal', 'alien',
  
  // Middle Eastern
  'sand', 'terrorist', 'bomber', 'raghead', 'camel',
  
  // White/Caucasian
  'cracker', 'honkey', 'white trash', 'redneck', 'hillbilly',
  
  // Native/Indigenous
  'redskin', 'savage', 'chief', 'squaw', 'injun'
];

// Cultural Appropriation
export const culturalAppropriation = [
  // General
  'appropriate', 'appropriation', 'stereotype', 'mock', 'mocking',
  'imitate', 'costume', 'dress up', 'accent', 'impersonation',
  
  // Cultural Elements
  'headdress', 'war paint', 'tribal', 'exotic', 'primitive',
  'savage', 'native', 'traditional', 'authentic', 'ethnic',
  
  // Mockery
  'ching chong', 'broken english', 'accent', 'dialect', 'slang',
  'ghetto', 'hood', 'thug', 'gangster', 'exotic'
];