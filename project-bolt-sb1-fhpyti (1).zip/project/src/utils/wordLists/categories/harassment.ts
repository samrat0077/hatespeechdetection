// Personal Attacks
export const personalAttacks = [
  // General Insults
  'stupid', 'idiot', 'dumb', 'moron', 'imbecile', 'retard',
  'loser', 'worthless', 'useless', 'pathetic', 'failure',
  
  // Appearance-based
  'ugly', 'fat', 'obese', 'skinny', 'anorexic', 'disgusting',
  'hideous', 'gross', 'deformed', 'disfigured',
  
  // Intelligence-based
  'brainless', 'dimwit', 'numbskull', 'halfwit', 'dunce',
  'ignorant', 'simpleton', 'fool', 'mindless',
  
  // Mental Health
  'crazy', 'insane', 'psycho', 'mental', 'deranged',
  'unstable', 'lunatic', 'delusional', 'schizo'
];

// Cyberbullying
export const cyberbullying = [
  // Direct Commands
  'kys', 'kill yourself', 'neck yourself', 'end yourself',
  'delete yourself', 'off yourself', 'jump off',
  
  // Online Harassment
  'doxx', 'swat', 'hack', 'leak', 'expose', 'cancel',
  'ratio', 'block', 'report', 'spam', 'troll',
  
  // Social Media
  'unfollow', 'block', 'mute', 'ghost', 'cancel',
  'expose', 'call out', 'drag', 'ratio',
  
  // Intimidation
  'watch out', 'better watch', 'coming for', 'find you',
  'track you', 'hunt you', 'expose you'
];

// Sexual Harassment
export const sexualHarassment = [
  // Unwanted Advances
  'stalk', 'creep', 'perv', 'predator', 'groomer',
  'molester', 'harasser', 'stalker', 'peeping',
  
  // Objectification
  'piece of', 'object', 'meat', 'body', 'curves',
  'assets', 'endowment', 'physical', 'looks',
  
  // Gender-based
  'sexist', 'misogynist', 'misandrist', 'chauvinist',
  'feminist', 'masculinist', 'patriarch', 'matriarch',
  
  // Sexual Violence
  'rape', 'assault', 'molest', 'grope', 'touch',
  'harass', 'violate', 'abuse', 'force'
];