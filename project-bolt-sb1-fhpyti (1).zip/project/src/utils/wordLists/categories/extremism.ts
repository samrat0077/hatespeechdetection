// Political Extremism
export const politicalExtremism = [
  // General
  'extremist', 'radical', 'terrorist', 'fascist', 'nazi',
  'genocide', 'authoritarian', 'dictator', 'oppression',
  'oppressor', 'regime', 'supremacy', 'militant',
  
  // Far-Right
  'alt-right', 'neo-nazi', 'white power', 'skinhead',
  'nationalist', 'fascist', 'race war', 'ethnostate',
  
  // Far-Left
  'antifa', 'anarchist', 'communist', 'marxist',
  'revolutionary', 'militant', 'radical',
  
  // Religious Extremism
  'jihadist', 'fundamentalist', 'radical', 'extremist',
  'militant', 'terrorist', 'holy war', 'crusade',
  
  // Separatist Movements
  'separatist', 'nationalist', 'independence', 'liberation',
  'freedom fighter', 'guerrilla', 'militant', 'insurgent'
];

// Violence Advocacy
export const violenceAdvocacy = [
  // Direct Violence
  'kill', 'murder', 'assassinate', 'eliminate', 'exterminate',
  'slaughter', 'massacre', 'genocide', 'purge', 'cleanse',
  
  // Threats
  'threat', 'threaten', 'intimidate', 'harass', 'stalk',
  'hunt down', 'coming for', 'watch out', 'better watch',
  
  // Weapons
  'gun', 'shoot', 'knife', 'stab', 'bomb', 'explode',
  'weapon', 'arsenal', 'ammunition', 'armed',
  
  // Death Threats
  'die', 'death', 'dead', 'grave', 'bury', 'funeral',
  'end you', 'finish you', 'take you out', 'put down',
  
  // Physical Violence
  'beat', 'hit', 'punch', 'kick', 'slap', 'fight',
  'attack', 'assault', 'strike', 'hurt', 'harm'
];