export const harassmentWords = [
  // Personal Attacks
  'stupid', 'idiot', 'dumb', 'moron', 'imbecile',
  'loser', 'worthless', 'useless', 'pathetic',
  'incompetent', 'failure', 'good-for-nothing',
  
  // Threats and Violence
  'kill', 'murder', 'die', 'death', 'dead',
  'hurt', 'punch', 'slap', 'attack', 'destroy',
  'eliminate', 'beat', 'fight', 'hit', 'strike',
  'shoot', 'stab', 'strangle', 'torture', 'suffer',
  
  // Cyberbullying
  'kys', 'neck yourself', 'end yourself',
  'delete yourself', 'off yourself',
  
  // Body Shaming
  'ugly', 'fat', 'obese', 'disgusting',
  'hideous', 'gross', 'deformed',
  
  // Mental Health Stigma
  'retard', 'psycho', 'crazy', 'insane', 'mental',
  
  // Social Exclusion
  'wannabe', 'poser', 'fake', 'fraud',
  'outcast', 'reject', 'loner', 'loser',
  
  // Stalking/Harassment
  'stalk', 'stalker', 'creep', 'creepy',
  'harass', 'harassment', 'follow',
  
  // Intimidation
  'watch out', 'better watch', 'coming for',
  'hunt you', 'find you', 'track you'
];