export const nsfwWords = [
  // Adult Content Indicators
  'nsfw', 'xxx', 'porn', 'pornographic',
  'adult', 'mature', '18+', 'rated x',
  
  // Explicit Content
  'nude', 'nudity', 'naked', 'explicit',
  'uncensored', 'unrated', 'erotic',
  
  // Adult Industry
  'escort', 'stripper', 'webcam',
  'onlyfans', 'premium snap',
  
  // Sexual Content
  'sex', 'sexual', 'sexy', 'seductive',
  'kinky', 'fetish', 'bdsm',
  
  // Inappropriate Content
  'lewd', 'perverted', 'indecent',
  'obscene', 'vulgar', 'graphic'
];