export const profanityWords = [
  // Common Profanity
  'ass', 'asshole', 'bastard', 'bitch', 'crap', 'damn', 'dammit',
  'dick', 'douche', 'douchebag', 'fuck', 'fucking', 'fuk', 'fucker',
  'hell', 'piss', 'pissed', 'shit', 'wtf', 'stfu', 'frick',
  
  // Mild Profanity
  'heck', 'dang', 'darn', 'suck', 'sucker', 'sucks',
  
  // Variations and Combinations
  'af', 'fml', 'gtfo', 'lmao', 'lmfao', 'omfg', 'stfu',
  'bs', 'bullshit', 'horseshit', 'jackass', 'mofo'
];