export const hateWords = [
  // Racial/Ethnic Discrimination
  'racist', 'supremacist', 'discrimination', 'supremacy',
  'ethnostate', 'segregation', 'xenophobe', 'xenophobia',
  
  // Religious Discrimination
  'islamophobic', 'islamophobia', 'antisemitic', 'antisemitism',
  'bigot', 'bigotry', 'zealot', 'infidel', 'heretic',
  
  // Identity-based Hate
  'homophobic', 'homophobia', 'transphobic', 'transphobia',
  'misogynist', 'misogyny', 'misandrist', 'misandry',
  'ableist', 'ableism', 'sexist', 'sexism',
  
  // Extremist Terms
  'extremist', 'radical', 'terrorist', 'fascist',
  'nazi', 'genocide', 'ethnic cleansing',
  
  // General Hate Speech
  'hate', 'hateful', 'disgusting', 'subhuman',
  'inferior', 'superior', 'master race', 'pure blood',
  
  // Discriminatory Actions
  'deport', 'deportation', 'ban', 'purge',
  'cleanse', 'eliminate', 'eradicate'
];