import { regionalDiscrimination, religiousDiscrimination, ethnicDiscrimination, culturalAppropriation } from './wordLists/categories/discrimination';
import { politicalExtremism, violenceAdvocacy } from './wordLists/categories/extremism';
import { personalAttacks, cyberbullying, sexualHarassment } from './wordLists/categories/harassment';
import { adultContent, explicitLanguage, illegalContent } from './wordLists/categories/nsfw';

const allWordLists = {
  discrimination: [...regionalDiscrimination, ...religiousDiscrimination, ...ethnicDiscrimination, ...culturalAppropriation],
  extremism: [...politicalExtremism, ...violenceAdvocacy],
  harassment: [...personalAttacks, ...cyberbullying, ...sexualHarassment],
  adult: [...adultContent, ...explicitLanguage],
  illegal: [...illegalContent]
};

export function highlightText(text: string): string {
  let highlightedText = text;
  const allWords = Object.values(allWordLists).flat();
  
  // Sort words by length (longest first) to handle overlapping matches correctly
  const sortedWords = [...new Set(allWords)].sort((a, b) => b.length - a.length);
  
  for (const word of sortedWords) {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    highlightedText = highlightedText.replace(
      regex,
      `<span class="text-red-600 border-b-2 border-red-600">$&</span>`
    );
  }
  
  return highlightedText;
}