import React from 'react';
import { motion } from 'framer-motion';
import { ShieldAlert } from 'lucide-react';
import { TextAnalyzer } from './components/TextAnalyzer';
import { InfoSection } from './components/InfoSection';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-center space-x-3"
          >
            <ShieldAlert className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Content Safety Analyzer</h1>
          </motion.div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Detect and Prevent Harmful Content
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our advanced AI helps you identify and moderate potentially harmful content
              to create safer online spaces for everyone.
            </p>
          </div>

          <TextAnalyzer />
          <InfoSection />
        </motion.div>
      </main>

      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-gray-600">
            Built with care for safer online communities
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;